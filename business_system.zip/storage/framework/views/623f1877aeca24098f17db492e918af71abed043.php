<div>
<?php echo e(Form::submit($value,$attributes)); ?>


</div>